from flask import Flask, request, jsonify, render_template_string
from twilio.rest import Client
from sqlalchemy import create_engine, Column, String, DateTime, Integer
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import os
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.secret_key = 'opd-chatbot'

TWILIO_ACCOUNT_SID = os.getenv('TWILIO_ACCOUNT_SID', '')
TWILIO_AUTH_TOKEN = os.getenv('TWILIO_AUTH_TOKEN', '')
TWILIO_WHATSAPP_NUMBER = os.getenv('TWILIO_WHATSAPP_NUMBER', '')

if TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN:
    twilio_client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///appointments.db')
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
Session = sessionmaker(bind=engine)
Base = declarative_base()

class Appointment(Base):
    __tablename__ = 'appointments'
    id = Column(Integer, primary_key=True)
    patient_phone = Column(String, nullable=False)
    patient_name = Column(String, nullable=False)
    appointment_date = Column(DateTime, nullable=False)
    reason = Column(String)
    status = Column(String, default='confirmed')
    created_at = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(engine)

@app.route('/')
def index():
    return render_template_string('''
    <html>
    <head>
        <title>OPD Chatbot</title>
        <style>
            body { font-family: Arial; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); height: 100vh; }
            .container { background: white; padding: 50px; border-radius: 10px; max-width: 600px; margin: 0 auto; }
            h1 { color: #333; }
            .btn { display: inline-block; margin: 10px; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; font-weight: bold; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🏥 OPD Appointment Chatbot</h1>
            <p>WhatsApp automated appointment booking system</p>
            <a class="btn" href="/dashboard">📊 Admin Dashboard</a>
            <a class="btn" href="/status">✅ API Status</a>
        </div>
    </body>
    </html>
    ''')

@app.route('/status')
def status():
    return jsonify({'status': 'active', 'service': 'OPD Chatbot'})

@app.route('/dashboard')
def dashboard():
    session = Session()
    appointments = session.query(Appointment).all()
    session.close()
    
    rows = ''.join([f'<tr><td>{apt.patient_name}</td><td>{apt.patient_phone}</td><td>{apt.appointment_date}</td><td>{apt.reason}</td></tr>' for apt in appointments])
    
    return render_template_string('''
    <html>
    <head>
        <title>Dashboard</title>
        <style>
            body { font-family: Arial; padding: 20px; background: #f0f0f0; }
            .container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
            table { width: 100%; border-collapse: collapse; }
            th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
            th { background: #667eea; color: white; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📊 Appointments Dashboard</h1>
    ''' + ('<table><tr><th>Patient</th><th>Phone</th><th>Date</th><th>Reason</th></tr>' + rows + '</table>' if appointments else '<p>No appointments yet</p>') + '''
        </div>
    </body>
    </html>
    ''')

@app.route('/webhook', methods=['POST'])
def webhook():
    incoming_msg = request.values.get('Body', 'Hi').strip()
    return '', 200

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
